# Archeologia Hub — Android

Wrapper Android offline della web-app Archeologia Hub V16.

## Build
Apri questa cartella in Android Studio e usa **Build > Build APK(s)**.
L'APK sarà in `app/build/outputs/apk/debug/app-debug.apk`.
