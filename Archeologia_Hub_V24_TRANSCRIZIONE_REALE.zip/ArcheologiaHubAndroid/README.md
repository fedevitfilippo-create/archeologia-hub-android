# Archeologia Hub — Android

Wrapper Android offline della web-app Archeologia Hub V16.

## Build
Apri questa cartella in Android Studio e usa **Build > Build APK(s)**.
L'APK sarà in `app/build/outputs/apk/debug/app-debug.apk`.


## V17 — Navigazione indietro
- Pulsante **‹ Indietro** visibile nell'app quando esiste una pagina precedente.
- Il pulsante torna alla pagina precedente della navigazione interna della WebApp.
- Il tasto/gesture **Indietro di Android** usa la stessa cronologia interna prima di chiudere l'app.


## V17.1 — Logo app
- Icona launcher personalizzata **Archeologia Hub**, ispirata all'archeologia romana con busto classico e corona d'alloro.
- Icone legacy e adaptive icon per Android moderni.
