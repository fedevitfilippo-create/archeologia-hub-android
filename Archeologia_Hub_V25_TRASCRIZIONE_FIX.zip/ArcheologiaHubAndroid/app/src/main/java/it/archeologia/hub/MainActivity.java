package it.archeologia.hub;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.Nullable;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import org.vosk.Model;
import org.vosk.Recognizer;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 4101;
    private static final int AUDIO_PICK_REQUEST = 4102;
    private String audioPickRequestId;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile Model voskModel;
    private static final String MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-it-0.22.zip";
    private static final String MODEL_DIR = "vosk-model-small-it-0.22";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        webView = new WebView(this);
        setContentView(webView);

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidApp");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                }
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { filePathCallback = null; callback.onReceiveValue(null); }
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(url);
            }
        });

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == AUDIO_PICK_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && audioPickRequestId != null) {
                Uri u = data.getData();
                try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
                String name = queryDisplayName(u);
                String mime = getContentResolver().getType(u);
                long size = querySize(u);
                final String callbackId = audioPickRequestId;
                main.post(() -> webView.evaluateJavascript("window.__nativeAudioPicked("+JSONObject.quote(callbackId)+","+JSONObject.quote(u.toString())+","+JSONObject.quote(name)+","+JSONObject.quote(mime==null?"audio/*":mime)+","+size+")", null));
            }
            audioPickRequestId = null;
            return;
        }
        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;
        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            Uri u = data.getData();
            if (u != null) {
                try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
                results = new Uri[]{u};
            }
        }
        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
    }

    private String queryDisplayName(Uri uri) {
        android.database.Cursor c=null;
        try { c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null); if(c!=null&&c.moveToFirst()) return c.getString(0); } catch(Exception ignored){} finally{if(c!=null)c.close();} return "Audio lezione";
    }
    private long querySize(Uri uri) {
        android.database.Cursor c=null;
        try { c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.SIZE},null,null,null); if(c!=null&&c.moveToFirst()&&!c.isNull(0)) return c.getLong(0); } catch(Exception ignored){} finally{if(c!=null)c.close();} return 0;
    }

    private boolean handleUrl(String url) {
        if (url == null) return false;
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme();
        if ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme) || "about".equalsIgnoreCase(scheme)) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
        return true;
    }

    private class AndroidBridge {
        @JavascriptInterface public void pickAudio(String requestId) {
            audioPickRequestId = requestId;
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("audio/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            try { startActivityForResult(i, AUDIO_PICK_REQUEST); } catch (Exception e) { audioPickRequestId=null; }
        }

        @JavascriptInterface public void transcribeAudio(final String uriString, final String requestId) {
            executor.execute(() -> {
                try {
                    File modelDir = ensureModel();
                    if (voskModel == null) voskModel = new Model(modelDir.getAbsolutePath());
                    final String text = transcribe(Uri.parse(uriString), voskModel);
                    sendTranscription(requestId, text, null);
                } catch (Exception e) {
                    sendTranscription(requestId, null, e.getMessage() == null ? "Errore durante la trascrizione" : e.getMessage());
                }
            });
        }
        @JavascriptInterface public boolean isNativeAvailable() { return true; }
        @JavascriptInterface public String appVersion() { return "V24"; }
    }

    private void sendTranscription(String id, String text, String error) {
        main.post(() -> {
            try {
                String js = "window.__nativeTranscriptionResult(" + JSONObject.quote(id) + "," + JSONObject.quote(text == null ? "" : text) + "," + JSONObject.quote(error == null ? "" : error) + ")";
                webView.evaluateJavascript(js, null);
            } catch (Exception ignored) {}
        });
    }

    private File ensureModel() throws Exception {
        File root = new File(getFilesDir(), "speech-model");
        File model = new File(root, MODEL_DIR);
        if (new File(model, "am/final.mdl").exists()) return model;
        if (!root.exists() && !root.mkdirs()) throw new Exception("Impossibile creare l'archivio del modello.");
        File zip = new File(root, "model.zip");
        if (!zip.exists() || zip.length() < 5_000_000) download(MODEL_URL, zip);
        unzip(zip, root);
        if (!new File(model, "am/final.mdl").exists()) throw new Exception("Modello italiano non valido.");
        zip.delete();
        return model;
    }

    private void download(String urlString, File out) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlString).openConnection();
        c.setConnectTimeout(20000); c.setReadTimeout(120000); c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "ArcheologiaHub/24");
        c.connect();
        if (c.getResponseCode() < 200 || c.getResponseCode() >= 300) throw new Exception("Download del modello non riuscito (HTTP " + c.getResponseCode() + ").");
        try (InputStream in = c.getInputStream(); OutputStream o = new FileOutputStream(out)) {
            byte[] b = new byte[1024 * 64]; int n; while ((n = in.read(b)) != -1) o.write(b, 0, n);
        } finally { c.disconnect(); }
    }

    private void unzip(File zipFile, File target) throws Exception {
        java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new FileInputStream(zipFile));
        java.util.zip.ZipEntry e;
        byte[] buf = new byte[1024 * 64];
        try {
            while ((e = zin.getNextEntry()) != null) {
                String name = e.getName();
                if (name.contains("..") || name.startsWith("/")) continue;
                File out = new File(target, name);
                if (e.isDirectory()) { if (!out.exists()) out.mkdirs(); continue; }
                File parent = out.getParentFile(); if (parent != null) parent.mkdirs();
                try (OutputStream os = new FileOutputStream(out)) { int n; while ((n = zin.read(buf)) != -1) os.write(buf,0,n); }
                zin.closeEntry();
            }
        } finally { zin.close(); }
    }

    private String transcribe(Uri uri, Model model) throws Exception {
        MediaExtractor extractor = new MediaExtractor();
        extractor.setDataSource(this, uri, null);
        int track = -1;
        for (int i=0;i<extractor.getTrackCount();i++) {
            MediaFormat f = extractor.getTrackFormat(i);
            String mime = f.getString(MediaFormat.KEY_MIME);
            if (mime != null && mime.startsWith("audio/")) { track=i; break; }
        }
        if (track < 0) throw new Exception("Nessuna traccia audio trovata.");
        extractor.selectTrack(track);
        MediaFormat format = extractor.getTrackFormat(track);
        String mime = format.getString(MediaFormat.KEY_MIME);
        int srcRate = format.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? format.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 16000;
        int channels = format.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 1;
        MediaCodec codec = MediaCodec.createDecoderByType(mime);
        codec.configure(format, null, null, 0);
        codec.start();
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        ByteArrayOutputStream pcm = new ByteArrayOutputStream();
        boolean inputDone=false, outputDone=false;
        try {
            while (!outputDone) {
                if (!inputDone) {
                    int inIndex=codec.dequeueInputBuffer(10000);
                    if(inIndex>=0){ByteBuffer in=codec.getInputBuffer(inIndex);int size=extractor.readSampleData(in,0);if(size<0){codec.queueInputBuffer(inIndex,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputDone=true;}else{long pts=extractor.getSampleTime();codec.queueInputBuffer(inIndex,0,size,pts,0);extractor.advance();}}
                }
                int outIndex=codec.dequeueOutputBuffer(info,10000);
                if(outIndex>=0){
                    ByteBuffer out=codec.getOutputBuffer(outIndex);
                    if(out!=null && info.size>0){byte[] b=new byte[info.size];out.position(info.offset);out.limit(info.offset+info.size);out.get(b);pcm.write(b);}
                    codec.releaseOutputBuffer(outIndex,false);if((info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0)outputDone=true;
                } else if(outIndex==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){ }
            }
        } finally { try{codec.stop();}catch(Exception ignored){} codec.release(); extractor.release(); }
        byte[] raw=pcm.toByteArray();
        int encoding = format.containsKey(MediaFormat.KEY_PCM_ENCODING) ? format.getInteger(MediaFormat.KEY_PCM_ENCODING) : android.media.AudioFormat.ENCODING_PCM_16BIT;
        short[] mono = toMono16(raw, channels, encoding);
        short[] resampled = resample(mono, srcRate, 16000);
        Recognizer rec = new Recognizer(model, 16000.0f);
        StringBuilder result = new StringBuilder();
        byte[] chunk = new byte[64000];
        ByteBuffer bb=ByteBuffer.wrap(chunk).order(ByteOrder.LITTLE_ENDIAN);
        int pos=0;
        while(pos<resampled.length){int samples=Math.min(resampled.length-pos,chunk.length/2);bb.clear();for(int i=0;i<samples;i++)bb.putShort(resampled[pos+i]);if(rec.acceptWaveForm(chunk,0,samples*2)){result.append(extractText(rec.getResult())).append(" ");}pos+=samples;}
        result.append(extractText(rec.getFinalResult()));
        rec.close();
        return result.toString().trim().replaceAll("\\s+"," ");
    }

    private String extractText(String json) { try { return new JSONObject(json).optString("text", ""); } catch(Exception e){ return ""; } }

    private short[] toMono16(byte[] raw, int channels, int encoding) {
        if (encoding == android.media.AudioFormat.ENCODING_PCM_FLOAT) {
            int frames=raw.length/4/Math.max(1,channels); short[] out=new short[frames]; ByteBuffer b=ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN);for(int i=0;i<frames;i++){float sum=0;for(int c=0;c<channels;c++)sum+=b.getFloat();sum/=Math.max(1,channels);out[i]=(short)Math.max(-32768,Math.min(32767,(int)(sum*32767f)));}return out;
        }
        int frames=raw.length/2/Math.max(1,channels); short[] out=new short[frames]; ByteBuffer b=ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN);for(int i=0;i<frames;i++){int sum=0;for(int c=0;c<channels;c++)sum+=b.getShort();out[i]=(short)(sum/Math.max(1,channels));}return out;
    }

    private short[] resample(short[] in, int from, int to) {
        if(from<=0 || from==to)return in; int outLen=(int)Math.round(in.length*(to/(double)from));short[] out=new short[outLen];for(int i=0;i<outLen;i++){double p=i*(from/(double)to);int a=(int)Math.floor(p);int b=Math.min(in.length-1,a+1);double f=p-a;out[i]=(short)Math.round(in[Math.min(a,in.length-1)]*(1-f)+in[b]*f);}return out;
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) { webView.goBack(); return; }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
            webView.evaluateJavascript("(window.hubBack ? window.hubBack() : false)", value -> { if ("false".equals(value) || "null".equals(value)) MainActivity.super.onBackPressed(); });
        } else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        executor.shutdownNow();
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }
}
